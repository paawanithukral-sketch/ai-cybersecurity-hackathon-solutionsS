# Problem 06 Drone Security

Solution approach and architecture.
