# Placeholder code for Problem 06_drone_security

print('Solution for 06_drone_security')
