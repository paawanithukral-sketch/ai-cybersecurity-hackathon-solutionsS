# Problem 04 Federated Learning

Solution approach and architecture.
