# Problem 08 Prompt Injection

Solution approach and architecture.
