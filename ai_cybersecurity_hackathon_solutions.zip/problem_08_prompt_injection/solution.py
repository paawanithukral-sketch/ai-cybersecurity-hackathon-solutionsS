# Placeholder code for Problem 08_prompt_injection

print('Solution for 08_prompt_injection')
