# Placeholder code for Problem 12_zero_trust

print('Solution for 12_zero_trust')
