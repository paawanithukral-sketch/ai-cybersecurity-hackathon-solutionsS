# Problem 12 Zero Trust

Solution approach and architecture.
