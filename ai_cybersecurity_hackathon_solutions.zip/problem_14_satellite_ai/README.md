# Problem 14 Satellite Ai

Solution approach and architecture.
