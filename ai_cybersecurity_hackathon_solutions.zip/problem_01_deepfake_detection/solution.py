# Placeholder code for Problem 01_deepfake_detection

print('Solution for 01_deepfake_detection')
