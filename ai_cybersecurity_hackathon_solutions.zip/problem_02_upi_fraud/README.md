# Problem 02 Upi Fraud

Solution approach and architecture.
