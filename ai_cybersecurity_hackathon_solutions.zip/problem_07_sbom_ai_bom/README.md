# Problem 07 Sbom Ai Bom

Solution approach and architecture.
