# Problem 05 Cyber Defense

Solution approach and architecture.
