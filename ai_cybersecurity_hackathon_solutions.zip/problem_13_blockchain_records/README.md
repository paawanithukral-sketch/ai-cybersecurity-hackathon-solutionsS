# Problem 13 Blockchain Records

Solution approach and architecture.
